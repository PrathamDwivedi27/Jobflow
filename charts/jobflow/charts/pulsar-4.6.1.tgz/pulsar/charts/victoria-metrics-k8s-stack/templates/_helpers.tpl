{{- define "vm.read.endpoint" -}}
  {{- $Values := (.helm).Values | default .Values -}}
  {{- $endpoint := dict -}}
  {{- $_ := set . "style" "managed" -}}
  {{- if $Values.vmsingle.enabled -}}
    {{- $_ := set . "appKey" (list "vmsingle" "spec") -}}
    {{- $_ := set $endpoint "url" (include "vm.url" .) -}}
  {{- else if and $Values.vmcluster.enabled $Values.vmcluster.spec.vmselect.enabled -}}
    {{- $_ := set . "appKey" (list "vmcluster" "spec" "vmselect") -}}
    {{- $baseURL := include "vm.url" . -}}
    {{- $tenant := $Values.tenant | default 0 -}}
    {{- $_ := set $endpoint "url" (printf "%s/select/%d/prometheus" $baseURL (int $tenant)) -}}
  {{- else if $Values.vmdistributed.enabled }}
    {{- $_ := set . "appKey" (list "vmdistributed" "spec" "vmauth" "spec") -}}
    {{- $baseURL := include "vm.url" . -}}
    {{- $tenant := $Values.tenant | default 0 -}}
    {{- $_ := set $endpoint "url" (printf "%s/select/%d/prometheus" $baseURL (int $tenant)) -}}
  {{- else if $Values.external.vm.read.url -}}
    {{- $endpoint = $Values.external.vm.read -}}
  {{- end -}}
  {{- with $endpoint -}}
    {{- toYaml . -}}
  {{- end -}}
{{- end }}

{{- define "vm.write.endpoint" -}}
  {{- $Values := (.helm).Values | default .Values -}}
  {{- $endpoint := dict -}}
  {{- $_ := set . "style" "managed" -}}
  {{- if $Values.vmsingle.enabled -}}
    {{- $_ := set . "appKey" (list "vmsingle" "spec") -}}
    {{- $baseURL := include "vm.url" . -}}
    {{- $_ := set $endpoint "url" (printf "%s/api/v1/write" $baseURL) -}}
  {{- else if and $Values.vmcluster.enabled $Values.vmcluster.spec.vminsert.enabled -}}
    {{- $_ := set . "appKey" (list "vmcluster" "spec" "vminsert") -}}
    {{- $baseURL := include "vm.url" . -}}
    {{- $tenant := $Values.tenant | default 0 -}}
    {{- $_ := set $endpoint "url" (printf "%s/insert/%d/prometheus/api/v1/write" $baseURL (int $tenant)) -}}
  {{- else if $Values.vmdistributed.enabled }}
    {{- $_ := set . "appKey" (list "vmdistributed" "spec" "vmauth" "spec") -}}
    {{- $baseURL := include "vm.url" . -}}
    {{- $tenant := $Values.tenant | default 0 -}}
    {{- $_ := set $endpoint "url" (printf "%s/insert/%d/prometheus/api/v1/write" $baseURL (int $tenant)) -}}
  {{- else if $Values.external.vm.write.url -}}
    {{- $endpoint = $Values.external.vm.write -}}
  {{- end -}}
  {{- with $endpoint -}}
    {{- toYaml . -}}
  {{- end -}}
{{- end -}}

{{- /* VMAlert remotes */ -}}
{{- define "vm.alert.remotes" -}}
  {{- $ctx := . -}}
  {{- $Values := (.helm).Values | default .Values -}}
  {{- $remotes := dict -}}
  {{- $fullname := include "vm.managed.fullname" . -}}
  {{- $_ := set $ctx "style" "managed" -}}
  {{- $remoteWrite := include "vm.write.endpoint" $ctx | fromYaml -}}
  {{- if and $Values.vmalert.remoteWriteVMAgent $Values.vmagent.enabled -}}
    {{- $_ := set $ctx "appKey" (list "vmagent" "spec") -}}
    {{- $remoteWrite = dict "url" (printf "%s/api/v1/write" (include "vm.url" $ctx)) -}}
    {{- $_ := unset $ctx "appKey" -}}
    {{- $_ := set $remotes "remoteWrite" $remoteWrite -}}
  {{- else -}}
    {{- $_ := set $remotes "remoteWrite" $remoteWrite -}}
  {{- end -}}
  {{- $readEndpoint := include "vm.read.endpoint" $ctx -}}
  {{- if $readEndpoint }}
    {{- $remoteRead := fromYaml $readEndpoint -}}
    {{- $_ := set $remotes "remoteRead" $remoteRead -}}
    {{- $_ := set $remotes "datasource" $remoteRead -}}
  {{- else if or (not $Values.vmalert.spec.datasource) (not $Values.vmalert.spec.remoteRead) -}}
    {{- fail "VM read source required! Either set `vmalert.enabled: false` or provide `vmalert.spec.remoteRead.url` and `vmalert.spec.datasource.url`" -}}
  {{- end -}}
  {{- if $Values.vmalert.additionalNotifierConfigs }}
    {{- $configName := printf "%s-additional-notifier" $fullname -}}
    {{- $notifierConfigRef := dict "name" $configName "key" "notifier-configs.yaml" -}}
    {{- $_ := set $remotes "notifierConfigRef" $notifierConfigRef -}}
  {{- else if $Values.alertmanager.enabled -}}
    {{- $notifiers := list -}}
    {{- $appSecure := not (empty ((($Values.alertmanager).spec).webConfig).tls_server_config) -}}
    {{- $_ := set $ctx "appKey" (list "alertmanager" "spec") -}}
    {{- $_ := set $ctx "appSecure" $appSecure -}}
    {{- $_ := set $ctx "appRoute" (($Values.alertmanager).spec).routePrefix -}}
    {{- $alertManagerReplicas := $Values.alertmanager.spec.replicaCount | default 1 | int -}}
    {{- range until $alertManagerReplicas -}}
      {{- $_ := set $ctx "appIdx" . -}}
      {{- $notifiers = append $notifiers (dict "url" (include "vm.url" $ctx)) -}}
      {{- $_ := unset $ctx "appIdx" }}
    {{- end }}
    {{- $_ := set $remotes "notifiers" $notifiers -}}
  {{- end -}}
  {{- toYaml $remotes -}}
{{- end -}}

{{- /* VMAlert templates */ -}}
{{- define "vm.alert.templates" -}}
  {{- $Values := (.helm).Values | default .Values -}}
  {{- $cms :=  ($Values.vmalert.spec.configMaps | default list) -}}
  {{- if $Values.vmalert.templateFiles -}}
    {{- $fullname := include "vm.managed.fullname" . -}}
    {{- $cms = append $cms (printf "%s-extra-tpl" $fullname) -}}
  {{- end -}}
  {{- $output := dict "configMaps" (compact $cms) -}}
  {{- toYaml $output -}}
{{- end -}}

{{- define "vm.license.global" -}}
  {{- $Values := (.helm).Values | default .Values -}}
  {{- $license := (deepCopy ($Values.global).license) | default dict -}}
  {{- if $license.key -}}
    {{- if hasKey $license "keyRef" -}}
      {{- $_ := unset $license "keyRef" -}}
    {{- end -}}
  {{- else if $license.keyRef.name -}}
    {{- if hasKey $license "key" -}}
      {{- $_ := unset $license "key" -}}
    {{- end -}}
  {{- else -}}
    {{- $license = dict -}}
  {{- end -}}
  {{- with $license -}}
    {{- toYaml . -}}
  {{- end -}}
{{- end -}}

{{- /* VMAlert spec */ -}}
{{- define "vm.alert.spec" -}}
  {{- $Values := (.helm).Values | default .Values }}
  {{- $Chart := (.helm).Chart | default .Chart }}
  {{- $image := dict "tag" (include "vm.image.tag" .) }}
  {{- $extraArgs := dict "remoteWrite.disablePathAppend" "true" -}}
  {{- $fullname := include "vm.managed.fullname" . }}
  {{- if $Values.vmalert.templateFiles -}}
    {{- $ruleTmpl := printf "/etc/vm/configs/%s-extra-tpl/*.tmpl" $fullname -}}
    {{- $_ := set $extraArgs "rule.templates" $ruleTmpl -}}
  {{- end -}}
  {{- $vmAlertTemplates := include "vm.alert.templates" . | fromYaml -}}
  {{- $vmAlertRemotes := include "vm.alert.remotes" . | fromYaml -}}
  {{- $spec := dict "extraArgs" $extraArgs "image" $image -}}
  {{- with (include "vm.license.global" .) -}}
    {{- $_ := set $spec "license" (fromYaml .) -}}
  {{- end -}}
  {{- with concat ($vmAlertRemotes.notifiers | default list) ($Values.vmalert.spec.notifiers | default list) }}
    {{- $_ := set $vmAlertRemotes "notifiers" . }}
  {{- end }}
  {{- $spec := deepCopy (omit $Values.vmalert.spec "notifiers") | mergeOverwrite $vmAlertRemotes | mergeOverwrite $vmAlertTemplates | mergeOverwrite $spec }}
  {{- if not (or (hasKey $spec "notifier") (hasKey $spec "notifiers") (hasKey $spec "notifierConfigRef") (hasKey $spec.extraArgs "notifier.blackhole")) }}
    {{- fail "Neither `notifier`, `notifiers` nor `notifierConfigRef` is set for vmalert. If it's intentionally please consider setting `.vmalert.spec.extraArgs.['notifier.blackhole']` to `'true'`"}}
  {{- end }}
  {{- $output := deepCopy (omit $Values.vmalert.spec "notifiers") | mergeOverwrite $vmAlertRemotes | mergeOverwrite $vmAlertTemplates | mergeOverwrite $spec -}}
  {{- if or $Values.grafana.enabled $Values.external.grafana.host }}
    {{- if not (index $output.extraArgs "external.alert.source") -}}
      {{- $alertSourceTpl := `{"datasource":%q,"queries":[{"expr":{{"{{"}} .Expr|jsonEscape|queryEscape {{"}}"}},"refId":"A"}],"range":{"from":"{{"{{"}} .ActiveAt.UnixMilli {{"}}"}}","to":"now"}}` -}}
      {{- $alertSource := "" -}}
      {{- if $Values.external.grafana.host -}}
        {{- $alertSource = printf $alertSourceTpl $Values.external.grafana.datasource -}}
      {{- else -}}
        {{- $alertSource = printf $alertSourceTpl (index $Values.defaultDatasources.victoriametrics.datasources 0 "name") -}}
      {{- end -}}
      {{- $_ := set $output.extraArgs "external.alert.source" (printf "explore?left=%s" $alertSource) -}}
    {{- end -}}
    {{- if not (index $output.extraArgs "external.url") -}}
      {{- $_ := set $output.extraArgs "external.url" (include "vm-k8s-stack.grafana.addr" .) -}}
    {{- end -}}
  {{- end -}}
  {{- tpl ($output | toYaml) . -}}
{{- end -}}

{{- /* VM Agent remoteWrites */ -}}
{{- define "vm.agent.remote.write" -}}
  {{- $Values := (.helm).Values | default .Values }}
  {{- $remoteWrites := $Values.vmagent.additionalRemoteWrites | default list }}
  {{- $rws := $Values.vmagent.spec.remoteWrite | default list }}
  {{- with include "vm.write.endpoint" . -}}
    {{- if $rws -}}
      {{- $rws = prepend (slice $rws 1) (mergeOverwrite (fromYaml .) (deepCopy (first $rws))) -}}
    {{- else -}}
      {{- $rws = append $rws (fromYaml .) -}}
    {{- end -}}
  {{- end -}}
  {{- $remoteWrites = concat $remoteWrites $rws }}
  {{- toYaml (dict "remoteWrite" $remoteWrites) -}}
{{- end -}}

{{- /* VMAgent spec */ -}}
{{- define "vm.agent.spec" -}}
  {{- $Values := (.helm).Values | default .Values }}
  {{- $Chart := (.helm).Chart | default .Chart }}
  {{- $image := dict "tag" (include "vm.image.tag" .) }}
  {{- $spec := include "vm.agent.remote.write" . | fromYaml -}}
  {{- with (include "vm.license.global" .) -}}
    {{- $_ := set $spec "license" (fromYaml .) -}}
  {{- end -}}
  {{- $_ := set $spec "image" $image -}}
  {{- tpl (mergeOverwrite (deepCopy $Values.vmagent.spec) (deepCopy $spec) | toYaml) . -}}
{{- end }}

{{- /* VMAuth spec */ -}}
{{- define "vm.auth.spec" -}}
  {{- $Values := (.helm).Values | default .Values }}
  {{- $image := dict "tag" (include "vm.image.tag" .) }}
  {{- $_ := set . "style" "managed" -}}
  {{- $vm := dict -}}
  {{- if $Values.vmsingle.enabled -}}
    {{- $_ := set . "appKey" (list "vmsingle" "spec") -}}
    {{- $url := urlParse (include "vm.url" .) -}}
    {{- $_ := set $vm "read" $url -}}
    {{- $_ := set $vm "write" $url -}}
  {{- else if $Values.vmcluster.enabled -}}
    {{- if $Values.vmcluster.spec.vminsert.enabled -}}
      {{- $_ := set . "appKey" (list "vmcluster" "spec" "vminsert") -}}
      {{- $writeURL := urlParse (include "vm.url" .) -}}
      {{- $_ := set $writeURL "path" (printf "%s/insert" $writeURL.path) -}}
      {{- $_ := set $vm "write" $writeURL }}
    {{- else if $Values.external.vm.write.url -}}
      {{- $_ := set $vm "write" (urlParse $Values.external.vm.write.url) -}}
    {{- end -}}
    {{- if $Values.vmcluster.spec.vmselect.enabled -}}
      {{- $_ := set . "appKey" (list "vmcluster" "spec" "vmselect") -}}
      {{- $readURL := urlParse (include "vm.url" .) -}}
      {{- $_ := set $readURL "path" (printf "%s/select" $readURL.path) -}}
      {{- $_ := set $vm "read" $readURL }}
    {{- else if $Values.external.vm.read.url -}}
      {{- $_ := set $vm "read" (urlParse $Values.external.vm.read.url) -}}
    {{- end -}}
    {{- $_ := set . "vm" $vm -}}
  {{- else if or $Values.external.vm.read.url $Values.external.vm.write.url -}}
    {{- with $Values.external.vm.read.url -}}
      {{- $_ := set $vm "read" (urlParse .) -}}
    {{- end -}}
    {{- with $Values.external.vm.write.url -}}
      {{- $_ := set $vm "write" (urlParse .) -}}
    {{- end -}}
  {{- end -}}
  {{- $_ := set . "vm" $vm -}}
  {{- $spec := deepCopy $Values.vmauth.spec }}
  {{- if $spec.unauthorizedUserAccessSpec }}
    {{- if $spec.unauthorizedUserAccessSpec.disabled }}
      {{- $_ := unset $spec "unauthorizedUserAccessSpec" }}
    {{- else -}}
      {{- $_ := unset $spec.unauthorizedUserAccessSpec "disabled" }}
    {{- end -}}
  {{- end -}}
  {{- $_ := set $spec "image" (mergeOverwrite (deepCopy $image) (deepCopy ($spec.image | default dict))) -}}
  {{- with (include "vm.license.global" .) -}}
    {{- $_ := set $spec "license" (fromYaml .) -}}
  {{- end -}}
  {{- tpl (toYaml $spec) . -}}
{{- end -}}

{{- /* Alermanager spec */ -}}
{{- define "vm.alertmanager.spec" -}}
  {{- $Values := (.helm).Values | default .Values }}
  {{- $fullname := include "vm.managed.fullname" . -}}
  {{- $app := $Values.alertmanager }}
  {{- $spec := $app.spec -}}
  {{- if and (not $spec.configRawYaml) (not $spec.configSecret) (not $Values.alertmanager.useManagedConfig) -}}
    {{- $_ := set $spec "configSecret" $fullname -}}
  {{- end -}}
  {{- $templates := $spec.templates | default list -}}
  {{- if $Values.alertmanager.monzoTemplate.enabled -}}
    {{- $configMap := printf "%s-monzo-tpl" $fullname -}}
    {{- $templates = append $templates (dict "name" $configMap "key" "monzo.tmpl") -}}
  {{- end -}}
  {{- $configMap := printf "%s-extra-tpl" $fullname -}}
  {{- range $key, $value := $Values.alertmanager.templateFiles | default dict -}}
    {{- $templates = append $templates (dict "name" $configMap "key" $key) -}}
  {{- end -}}
  {{- if and ($app.useManagedConfig) (not (hasKey $spec "disableNamespaceMatcher")) }}
    {{- $_ := set $spec "disableNamespaceMatcher" true }}
  {{- end }}
  {{- $_ := set $spec "templates" $templates -}}
  {{- toYaml $spec -}}
{{- end -}}

{{- /* Single spec */ -}}
{{- define "vm.single.spec" -}}
  {{- $Values := (.helm).Values | default .Values }}
  {{- $Chart := (.helm).Chart | default .Chart }}
  {{- $image := dict "tag" (include "vm.image.tag" .) }}
  {{- $extraArgs := dict -}}
  {{- $_ := set . "style" "managed" -}}
  {{- if $Values.vmalert.enabled }}
    {{- $_ := set . "appKey" (list "vmalert" "spec") }}
    {{- $_ := set $extraArgs "vmalert.proxyURL" (include "vm.url" .) -}}
  {{- end -}}
  {{- $spec := dict "extraArgs" $extraArgs "image" $image -}}
  {{- with (include "vm.license.global" .) -}}
    {{- $_ := set $spec "license" (fromYaml .) -}}
  {{- end -}}
  {{- tpl (deepCopy $Values.vmsingle.spec | mergeOverwrite $spec | toYaml) . -}}
{{- end }}

{{- /* Cluster spec */ -}}
{{- define "vm.select.spec" -}}
  {{- $Values := (.helm).Values | default .Values }}
  {{- $Chart := (.helm).Chart | default .Chart }}
  {{- $extraArgs := dict -}}
  {{- $_ := set . "style" "managed" -}}
  {{- if $Values.vmalert.enabled -}}
    {{- $_ := set . "appKey" (list "vmalert" "spec") -}}
    {{- $_ := set $extraArgs "vmalert.proxyURL" (include "vm.url" .) -}}
  {{- end -}}
  {{- $spec := dict "extraArgs" $extraArgs -}}
  {{- toYaml $spec -}}
{{- end -}}

{{- define "vm.cluster.spec" -}}
  {{- $Values := (.helm).Values | default .Values }}
  {{- $Chart := (.helm).Chart | default .Chart }}
  {{- $selectSpec := include "vm.select.spec" . | fromYaml -}}
  {{- $clusterSpec := deepCopy $Values.vmcluster.spec -}}
  {{- $clusterSpec = mergeOverwrite (dict "clusterVersion" (printf "%s-cluster" (include "vm.image.tag" .))) $clusterSpec -}}
  {{- with (include "vm.license.global" .) -}}
    {{- $_ := set $clusterSpec "license" (fromYaml .) -}}
  {{- end -}}
  {{- if ($clusterSpec.requestsLoadBalancer).enabled }}
    {{- $balancerSpec := $clusterSpec.requestsLoadBalancer.spec | default dict }}
    {{- $authImage := dict "image" (dict "tag" (include "vm.image.tag" .)) }}
    {{- $_ := set $clusterSpec.requestsLoadBalancer "spec" (mergeOverwrite $authImage $balancerSpec) }}
  {{- end }}
  {{- $clusterSpec = mergeOverwrite (dict "vmselect" $selectSpec) $clusterSpec }}
  {{- if not $clusterSpec.vmselect.enabled -}}
    {{- $_ := unset $clusterSpec "vmselect" -}}
  {{- else -}}
    {{- $_ := unset $clusterSpec.vmselect "enabled" -}}
  {{- end -}}
  {{- if not $clusterSpec.vminsert.enabled -}}
    {{- $_ := unset $clusterSpec "vminsert" -}}
  {{- else -}}
    {{- $_ := unset $clusterSpec.vminsert "enabled" -}}
  {{- end -}}
  {{- tpl (toYaml $clusterSpec) . -}}
{{- end -}}

{{- define "vm.distributed.spec" -}}
  {{- $Values := (.helm).Values | default .Values }}
  {{- $Chart := (.helm).Chart | default .Chart }}
  {{- $selectSpec := include "vm.select.spec" . | fromYaml -}}
  {{- $distributedSpec := deepCopy (($Values.vmdistributed).spec | default dict) -}}
  {{- $clusterSpec := deepCopy ((($distributedSpec.zoneCommon).vmcluster).spec | default dict) -}}
  {{- $clusterSpec = mergeOverwrite (dict "clusterVersion" (printf "%s-cluster" (include "vm.image.tag" .))) $clusterSpec -}}
  {{- with (include "vm.license.global" .) -}}
    {{- $_ := set $distributedSpec "license" (fromYaml .) -}}
  {{- end -}}
  {{- if ($clusterSpec.requestsLoadBalancer).enabled }}
    {{- $balancerSpec := $clusterSpec.requestsLoadBalancer.spec | default dict }}
    {{- $authImage := dict "image" (dict "tag" (include "vm.image.tag" .)) }}
    {{- $_ := set $clusterSpec.requestsLoadBalancer "spec" (mergeOverwrite $authImage $balancerSpec) }}
  {{- end }}
  {{- $clusterSpec = mergeOverwrite (dict "vmselect" $selectSpec) $clusterSpec }}
  {{- $distributedSpec = mergeOverwrite (dict "zoneCommon" (dict "vmcluster" (dict "spec" $clusterSpec))) $distributedSpec }}

  {{- $agentSpec := deepCopy ((($distributedSpec.zoneCommon).vmagent).spec | default dict) }}
  {{- $image := dict "tag" (include "vm.image.tag" .) }}
  {{- $_ := set $agentSpec "image" $image -}}
  {{- $distributedSpec = mergeOverwrite (dict "zoneCommon" (dict "vmagent" (dict "spec" $agentSpec))) $distributedSpec }}
  {{- tpl (toYaml $distributedSpec) . -}}
{{- end -}}

{{- define "vm.data.source.enabled" -}}
  {{- $Values := (.helm).Values | default .Values -}}
  {{- $grafana := $Values.grafana -}}
  {{- $installed := list }}
  {{- range $plugin := ($grafana.plugins | default list) -}}
    {{- $plugin = splitList "@" $plugin | first }}
    {{- $installed = append $installed $plugin }}
  {{- end -}}
  {{- $ds := .ds -}}
  {{- toString (or (not (hasKey $ds "version")) (has $ds.type $installed)) -}}
{{- end -}}

{{- /* Datasources */ -}}
{{- define "vm.data.sources" -}}
  {{- $ctx := . }}
  {{- $Values := (.helm).Values | default .Values }}
  {{- $datasources := $Values.defaultDatasources.extra | default list -}}
  {{- $readURL := include "vm.read.endpoint" $ctx -}}
  {{- if $readURL -}}
    {{- $readEndpoint := fromYaml $readURL -}}
    {{- $defaultDatasources := list -}}
    {{- range $ds := $Values.defaultDatasources.victoriametrics.datasources }}
      {{- $_ := set $ds "url" $readEndpoint.url -}}
      {{- $defaultDatasources = append $defaultDatasources $ds -}}
    {{- end }}
    {{- $datasources = concat $datasources $defaultDatasources -}}
  {{- end -}}
  {{- if $Values.alertmanager.enabled -}}
    {{- range $ds := $Values.defaultDatasources.alertmanager.datasources }}
      {{- $appSecure := not (empty ((($Values.alertmanager).spec).webConfig).tls_server_config) -}}
      {{- $_ := set $ctx "appKey" (list "alertmanager" "spec") -}}
      {{- $_ := set $ctx "appSecure" $appSecure -}}
      {{- $_ := set $ctx "appRoute" (($Values.alertmanager).spec).routePrefix -}}
      {{- $_ := set $ds "url" (include "vm.url" $ctx) -}}
      {{- $_ := set $ds "type" "alertmanager" -}}
      {{- $datasources = append $datasources $ds -}}
    {{- end }}
  {{- end -}}
  {{- toYaml (dict "datasources" $datasources) -}}
{{- end }}

{{- /* VMRule name */ -}}
{{- define "vm-k8s-stack.rulegroup.name" -}}
  {{- printf "%s-%s" (include "vm.fullname" .) (.name | replace "_" "") -}}
{{- end -}}

{{- /* VMRule labels */ -}}
{{- define "vm-k8s-stack.rulegroup.labels" -}}
  {{- $Values := (.helm).Values | default .Values }}
  {{- $labels := fromYaml (include "vm.labels" .) -}}
  {{- $_ := set $labels "app" (include "vm.name" .) -}}
  {{- $labels = mergeOverwrite $labels (deepCopy $Values.defaultRules.labels) -}}
  {{- toYaml $labels -}}
{{- end }}

{{- /* VMRule key */ -}}
{{- define "vm-k8s-stack.rulegroup.key" -}}
  {{- without (regexSplit "[-_.]" .name -1) "exporter" "rules" | join "-" | camelcase | untitle -}}
{{- end -}}

{{- /* VMAlertmanager name */ -}}
{{- define "vm-k8s-stack.alertmanager.name" -}}
  {{- $Values := (.helm).Values | default .Values }}
  {{- $_ := set . "appKey" (list "alertmanager" "spec") -}}
  {{- $Values.alertmanager.name | default (include "vm.managed.fullname" .) -}}
{{- end -}}

{{- define "vm-k8s-stack.nodeExporter.name" -}}
  {{- $Values := (.helm).Values | default .Values }}
  {{- (index $Values "prometheus-node-exporter").service.labels.jobLabel | default "node-exporter" }}
{{- end -}}

{{- define "vm-k8s-stack.grafana.addr" -}}
  {{- $Values := (.helm).Values | default .Values -}}
  {{- $grafanaAddr := (($Values.external).grafana).host -}}
  {{- if not (or (hasPrefix "http://" $grafanaAddr) (hasPrefix "https://" $grafanaAddr)) -}}
    {{- $grafanaAddr = printf "http://%s" $grafanaAddr -}}
  {{- end -}}
  {{- if ($Values.grafana).enabled -}}
    {{- $grafanaScheme := ternary "https" "http" (gt (len (($Values.grafana).ingress).tls) 0) -}}
    {{- $grafanaHosts := (($Values.grafana).ingress).hosts | default list }}
    {{- if eq (len $grafanaHosts) 0 }}
      {{- fail ".Values.grafana.ingress.hosts should not be empty if .Values.grafana.enabled is true" }}
    {{- end }}
    {{- $grafanaAddr = printf "%s://%s" $grafanaScheme (index $grafanaHosts 0) -}}
  {{- end -}}
  {{- $grafanaAddr -}}
{{- end -}}
